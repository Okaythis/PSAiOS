//
//  OperationType.h
//  PSA
//
//  Created by Borovik, Edgar2 on 1/30/20.
//

typedef NS_ENUM (NSInteger, OperationType) {
    InternalPayment = 0,
    RestoreUserPassword = 1,
    ChangeEmail = 2,
    VerifyEmail = 4,
    VerifyPhone = 5,
    ChangePhone = 6,
    Registration = 8,
    Authorization = 9,
    ChangeUserPassword = 10,
    ChangePaymentPassword = 11,
    MassPayment = 12,
    IncomingBankWire = 13,
    IncomingBankWireWithIncorrectDetails = 14,
    ChangeEmailEnterUserPassword = 15,
    ChangePhoneEnterUserPassword = 16,
    OutgoingBankWireForAdminPanel = 18,
    MerchantInvoice = 19,
    RefundInvoice = 20,
    OutgoingTransferToCryptocurrency = 21,
    UnblockCard = 22,
    SetPin = 23,
    GetPin = 24,
    CardUnloadForAdminPanel = 25,
    OperationConfirm = 26,
    TwoFactorAuthConfirm = 27,
    GoogleTwoFactorAuthEnable = 28,
    GoogleTwoFactorAuthDisable = 29,
    TwoFactorAuthorization = 30,
    TwoFaReset = 31,
    PaymentOperationConfirm = 32,
    NewIndividualMemberRegistration = 33,
    RestoreUserPasswordV2 = 34,
    SmsTwoFactorAuthEnable = 35,
    SmsTwoFactorAuthDisable = 36,
    RegistrationWithNpCard = 108,
    CardConfirmation = 105,
    AddUserDevice = 109,
    WithdrawingMoneyFromTerminal = 110,
    RegistrationVerifyEmail = 200,
    RegistrationVerifyPhone = 201
};
